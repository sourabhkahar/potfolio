<script setup>
import { MoveRight, Zap, Globe, Sparkles, MonitorSmartphone, ChevronLeft, ChevronRight } from 'lucide-vue-next'

const projectsContainer = ref(null)
const projectsTrack = ref(null)

const featuredProjects = [
  {
    id: 1,
    title: 'XS Pilates',
    category: 'CMS',
    image: '/images/projects/x-pilates.png',
    tags: ['jquery','css','html','php'],
    link: 'https://xs-pilates.com/',
  },
  {
    id: 2,
    title: 'Golfo Radio',
    category: 'Frontend',
    image: '/images/projects/golfo-radio.png',
    tags: ['Vue', 'Tailwind', 'axios','Figma'],
    link: 'https://golforadio.com/'
  },
  {
    id: 3,
    title: 'Hair Creation',
    category: 'HRMS/CMS',
    image: '/images/projects/hair-creation.png',
    tags: ['Vue', 'Tailwind', 'firebase'],
    link: 'https://hair-creation-8ffc3.web.app/'
  },
  {
    id: 4,
    title: 'Capmagic',
    category: 'Data Analysis Tool',
    image: '/images/projects/capmagic.png',
    tags: ['Vue', 'Vuetify', 'Laravel','PostgreSQL'],
    link: 'https://capmagic.net/'
  },
  {
    id: 5,
    title: 'Ashray Infrastructure',
    category: 'Finance App',
    image: '/images/projects/ashray-infrastructure.png',
    tags: ['Golang', 'Vue', 'PostgreSQL','tailwind'],
    link: 'https://app.ashrayinfrastructure.com/'
  },
  {
    id: 6,
    title: 'Sarvesukhantu Swaha',
    category: 'CMS',
    image: '/images/projects/sarvesukhantu.png',
    tags: ['Tailwind', 'Apline', 'Laravel','Livewire', 'MySQL'],
    link: 'https://sarvesukhantuswaha.org/'
  },
]

onMounted(async () => {
  if (!process.client) return
  
  // Dynamically import GSAP only on client
  const { default: gsap } = await import('gsap')
  const { ScrollTrigger } = await import('gsap/ScrollTrigger')
  
  gsap.registerPlugin(ScrollTrigger)

  if (!projectsTrack.value || !projectsContainer.value) return

  // Small delay to ensure DOM is ready
  await nextTick()
  
  const ctx = gsap.matchMedia()
  
  ctx.add("(min-width: 1024px)", () => {
    const track = projectsTrack.value
    const cards = track.querySelectorAll('.project-card-horizontal')
    const scrollWidth = track.scrollWidth - window.innerWidth

    gsap.to(track, {
      x: -scrollWidth,
      ease: 'none',
      scrollTrigger: {
        trigger: projectsContainer.value,
        start: 'top top',
        end: () => `+=${scrollWidth + 500}`,
        scrub: 1,
        pin: true,
        anticipatePin: 1,
        invalidateOnRefresh: true
      }
    })

    // Parallax effect for cards
    cards.forEach((card, i) => {
      gsap.fromTo(card, 
        { scale: 0.95 },
        {
          opacity: 1,
          scale: 1,
          ease: 'none',
          scrollTrigger: {
            trigger: projectsContainer.value,
            start: `top+=${i * 80} top`,
            end: `top+=${(i + 1) * 80} top`,
            scrub: true,
          }
        }
      )
    })
  })
})
const scrollNext = () => {
  if (projectsContainer.value) {
    const cardWidth = projectsContainer.value.querySelector('.project-card-horizontal')?.offsetWidth || 300
    projectsContainer.value.scrollBy({ left: cardWidth + 24, behavior: 'smooth' })
  }
}

const scrollPrev = () => {
  if (projectsContainer.value) {
    const cardWidth = projectsContainer.value.querySelector('.project-card-horizontal')?.offsetWidth || 300
    projectsContainer.value.scrollBy({ left: -(cardWidth + 24), behavior: 'smooth' })
  }
}
</script>

<template>
  <div class="overflow-x-hidden">
    <!-- 3D Entry Section -->
    <client-only>
      <Skills3D />
    </client-only>

    <!-- Intro Section -->
    <section id="about" class="relative pt-20 pb-40 min-h-screen flex items-center overflow-hidden">
      <div class="max-w-7xl mx-auto px-6 relative z-10 w-full">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <!-- Left: Floating Image -->
          <div class="relative group order-2 md:order-1">
            <div class="intro-image-container relative z-10 floating">
              <div class="absolute -inset-4 bg-[#F2613F]/20 blur-2xl rounded-3xl group-hover:bg-[#F2613F]/30 transition-all duration-700"></div>
              <img 
                src="/images/about-me.png" 
                alt="Profile" 
                class="relative rounded-3xl shadow-2xl border-2 border-white/50 grayscale hover:grayscale-0 transition-all duration-700 w-full aspect-[4/5] object-cover"
              />
              <!-- Glitch Overlay Overlay -->
              <div class="absolute inset-0 rounded-3xl mix-blend-overlay opacity-0 group-hover:opacity-40 bg-gradient-to-tr from-[#F2613F] to-[#9B3922] transition-opacity duration-500"></div>
            </div>
            
            <!-- Background Elements -->
            <div class="absolute -bottom-10 -left-10 w-40 h-40 bg-[#9B3922]/20 rounded-full blur-3xl animate-pulse"></div>
            <div class="absolute -top-10 -right-10 w-32 h-32 bg-[#F2613F]/20 rounded-full blur-3xl animate-pulse delay-700"></div>
          </div>

          <!-- Right: Introduction -->
          <div class="flex flex-col gap-8 order-1 md:order-2">
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#F2613F]/10 border border-[#F2613F]/30 text-[#F2613F] text-sm font-bold w-fit animate-bounce whitespace-nowrap">
              <Sparkles class="w-4 h-4" />
              ABOUT ME
            </div>
            
            <h1 class="text-5xl md:text-8xl font-black font-heading leading-none tracking-tighter">
              <span class="glitch" data-text="CRAFTING">CRAFTING</span> THE <br />
              <span class="text-glow glitch" data-text="DIGITAL FUTURE">DIGITAL FUTURE</span>
            </h1>
            
            <p class="text-white/95 text-lg md:text-xl leading-relaxed border-l-4 border-[#F2613F] pl-6 italic font-medium">
              "I'm a visionary full-stack developer dedicated to building immersive, 
              high-performance web experiences that push boundaries and redefine 
              how we interact with the digital world."
            </p>

            <div class="flex flex-wrap gap-6 pt-4">
              <NuxtLink to="#projects" class="btn-premium">
                EXPLORE MY WORK
                <MoveRight class="w-5 h-5" />
              </NuxtLink>
              <NuxtLink to="#contact" class="px-8 py-4 rounded-2xl border-2 border-[#F2613F] font-bold hover:bg-[#F2613F] hover:text-white transition-colors text-[#F2613F] flex items-center gap-2 group">
                LET'S CHAT
                <Zap class="w-5 h-5 group-hover:scale-125 transition-transform" />
              </NuxtLink>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Decorative Elements -->
      <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-[#F2613F]/5 rounded-full blur-[120px] -z-1" />
    </section>

    <!-- Horizontal Scrolling Projects -->
    <section class="py-20 bg-black/40" id="projects">
      <div class="max-w-7xl mx-auto px-6 mb-12">
        <h2 class="text-5xl md:text-7xl font-black mb-4 uppercase">SELECTED<br /><span class="text-[#F2613F]">WORKS.</span></h2>
        <p class="text-white/80 text-lg max-w-md">Scroll horizontally to explore my favorite projects.</p>
      </div>

      <div ref="projectsContainer" class="relative lg:h-screen lg:overflow-hidden overflow-x-auto snap-x snap-mandatory scroll-smooth hide-scrollbar">
        <div ref="projectsTrack" class="desktop-track lg:absolute lg:top-1/2 lg:left-0 lg:-translate-y-1/2 flex gap-6 lg:gap-8 px-6 lg:px-12 py-8">
          <div 
            v-for="project in featuredProjects" 
            :key="project.id" 
            class="project-card-horizontal flex-shrink-0 w-[85vw] lg:w-[450px] glass-card overflow-hidden snap-center"
          >
            <div class="aspect-[4/3] relative overflow-hidden">
              <img :src="project.image" :alt="project.title" class="w-full h-full object-cover" />
              <div class="absolute inset-0 bg-gradient-to-t from-[#0C0C0C] via-transparent to-transparent flex items-end p-6">
                <div class="flex gap-2">
                  <span v-for="tag in project.tags" :key="tag" class="px-3 py-1 rounded-md bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-bold text-[#F2613F] uppercase tracking-wider">{{ tag }}</span>
                </div>
              </div>
            </div>
            <div class="p-6">
              <p class="text-[#F2613F] font-bold text-xs uppercase tracking-widest mb-2">{{ project.category }}</p>
              <h3 class="text-2xl font-bold text-white mb-4">{{ project.title }}</h3>
              <a :href="project.link" target="_blank" class="inline-flex items-center gap-2 text-sm font-black text-white/80 hover:text-[#F2613F] transition-colors">
                VIEW DETAILS
                <MoveRight class="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>

      <!-- Mobile Navigation Arrows (Bottom) -->
      <div class="flex justify-center gap-6 mt-12 lg:hidden">
        <button @click="scrollPrev" class="w-14 h-14 rounded-full border-2 border-[#F2613F]/30 flex items-center justify-center text-white hover:bg-[#F2613F] hover:border-[#F2613F] transition-all active:scale-90 shadow-lg shadow-[#F2613F]/10" aria-label="Previous Project">
          <ChevronLeft class="w-7 h-7" />
        </button>
        <button @click="scrollNext" class="w-14 h-14 rounded-full border-2 border-[#F2613F]/30 flex items-center justify-center text-white hover:bg-[#F2613F] hover:border-[#F2613F] transition-all active:scale-90 shadow-lg shadow-[#F2613F]/10" aria-label="Next Project">
          <ChevronRight class="w-7 h-7" />
        </button>
      </div>

      <!-- View All Button Section -->
      <div class="max-w-7xl mx-auto px-6 mt-20 text-center">
        <NuxtLink to="/projects" class="group inline-flex items-center gap-4 text-[#F2613F] font-bold text-lg">
          VIEW ALL PROJECTS
          <div class="w-12 h-12 rounded-full border-2 border-[#F2613F] flex items-center justify-center group-hover:bg-[#F2613F] group-hover:text-white transition-all">
            <MoveRight class="w-5 h-5" />
          </div>
        </NuxtLink>
      </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="py-40 relative overflow-hidden">
      <div class="max-w-7xl mx-auto px-6 relative z-10">
        <div class="mb-20">
          <p class="text-[#F2613F] font-black tracking-[0.3em] uppercase text-sm mb-4">Core Expertise</p>
          <h2 class="text-5xl md:text-7xl font-black text-white uppercase">UNMATCHED<br /><span class="text-[#F2613F] glitch" data-text="CAPABILITIES.">CAPABILITIES.</span></h2>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <!-- Service 1 -->
          <div class="glass-card p-10 group relative overflow-hidden">
            <span class="absolute top-6 right-8 text-4xl font-black text-[#F2613F]/10 group-hover:text-[#F2613F]/20 transition-colors">01</span>
            <div class="w-16 h-16 rounded-2xl bg-[#F2613F]/10 border border-[#F2613F]/20 flex items-center justify-center text-[#F2613F] mb-8 group-hover:scale-110 transition-transform duration-500">
              <Zap class="w-8 h-8" />
            </div>
            <h4 class="text-2xl font-black text-white mb-4 uppercase tracking-tight group-hover:text-[#F2613F] transition-colors">Ultra Fast Performance</h4>
            <p class="text-white/80 leading-relaxed text-base">
              We engineer applications with a "speed-first" mindset, utilizing Edge computing and optimized 
              rendering patterns to achieve sub-second load times.
            </p>
            <div class="mt-8 pt-6 border-t border-white/5 opacity-0 group-hover:opacity-100 transition-opacity">
              <span class="text-xs font-bold text-[#F2613F]">IMMEDIATE RESPONSE • ZERO LAG</span>
            </div>
          </div>

          <!-- Service 2 -->
          <div class="glass-card p-10 group relative overflow-hidden">
            <span class="absolute top-6 right-8 text-4xl font-black text-[#F2613F]/10 group-hover:text-[#F2613F]/20 transition-colors">02</span>
            <div class="w-16 h-16 rounded-2xl bg-[#F2613F]/10 border border-[#F2613F]/20 flex items-center justify-center text-[#F2613F] mb-8 group-hover:scale-110 transition-transform duration-500">
              <Globe class="w-8 h-8" />
            </div>
            <h4 class="text-2xl font-black text-white mb-4 uppercase tracking-tight group-hover:text-[#F2613F] transition-colors">Modern Stack</h4>
            <p class="text-white/80 leading-relaxed text-base">
              Leveraging the absolute latest in Nuxt, TypeScript, and Serverless technologies to 
              create resilient, future-proof digital products that scale to millions.
            </p>
            <div class="mt-8 pt-6 border-t border-white/5 opacity-0 group-hover:opacity-100 transition-opacity">
              <span class="text-xs font-bold text-[#F2613F]">VUE  • NUXT • LARAVEL</span>
            </div>
          </div>

          <!-- Service 3 -->
          <div class="glass-card p-10 group relative overflow-hidden">
            <span class="absolute top-6 right-8 text-4xl font-black text-[#F2613F]/10 group-hover:text-[#F2613F]/20 transition-colors">03</span>
            <div class="w-16 h-16 rounded-2xl bg-[#F2613F]/10 border border-[#F2613F]/20 flex items-center justify-center text-[#F2613F] mb-8 group-hover:scale-110 transition-transform duration-500">
              <Sparkles class="w-8 h-8" />
            </div>
            <h4 class="text-2xl font-black text-white mb-4 uppercase tracking-tight group-hover:text-[#F2613F] transition-colors">Immersive Visuals</h4>
            <p class="text-white/80 leading-relaxed text-base">
              Blending high-end 3D graphics (Three.js) with precise motion design (GSAP) to tell 
              your brand's story through captivating interactive experiences.
            </p>
            <div class="mt-8 pt-6 border-t border-white/5 opacity-0 group-hover:opacity-100 transition-opacity">
              <span class="text-xs font-bold text-[#F2613F]">WEBGL • GSAP • THREE.JS</span>
            </div>
          </div>

          <!-- Service 4 -->
          <div class="glass-card p-10 group relative overflow-hidden">
            <span class="absolute top-6 right-8 text-4xl font-black text-[#F2613F]/10 group-hover:text-[#F2613F]/20 transition-colors">04</span>
            <div class="w-16 h-16 rounded-2xl bg-[#F2613F]/10 border border-[#F2613F]/20 flex items-center justify-center text-[#F2613F] mb-8 group-hover:scale-110 transition-transform duration-500">
              <MonitorSmartphone class="w-8 h-8" />
            </div>
            <h4 class="text-2xl font-black text-white mb-4 uppercase tracking-tight group-hover:text-[#F2613F] transition-colors">Responsive Design</h4>
            <p class="text-white/80 leading-relaxed text-base">
              Crafting seamless experiences that perform beautifully across all devices, from 
              ultra-wide monitors to the smallest mobile screens.
            </p>
            <div class="mt-8 pt-6 border-t border-white/5 opacity-0 group-hover:opacity-100 transition-opacity">
              <span class="text-xs font-bold text-[#F2613F]">MOBILE-FIRST • FLUID • ADAPTIVE</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Background Glow -->
      <div class="absolute -bottom-20 -left-20 w-[600px] h-[600px] bg-[#9B3922]/5 rounded-full blur-[120px] pointer-events-none"></div>
    </section>

    <!-- Contact CTA -->
    <section id="contact" class="py-40 relative px-6">
      <div class="max-w-5xl mx-auto glass-card p-12 md:p-24 text-center overflow-hidden border-[#9B3922]/40 relative">
        <div class="relative z-10">
          <h2 class="text-4xl md:text-7xl font-black mb-10 leading-tight text-white uppercase">HAVE A <span class="text-[#F2613F]">BIG IDEA?</span></h2>
          <p class="text-white/90 text-lg md:text-xl max-w-xl mx-auto mb-16 font-medium">
            I'm currently looking for new opportunities and collaborations. 
            Let's build something that changes the game.
          </p>
          <a href="mailto:sourabhkahar@gmail.com" class="btn-premium inline-flex mx-auto">
            WORK WITH ME
            <MoveRight class="w-5 h-5" />
          </a>
        </div>
        
        <!-- Abstract gradient background inside card -->
        <div class="absolute top-0 right-0 w-96 h-96 bg-[#F2613F]/10 blur-[100px] rounded-full pointer-events-none" />
        <div class="absolute bottom-0 left-0 w-96 h-96 bg-[#9B3922]/10 blur-[100px] rounded-full pointer-events-none" />
      </div>
    </section>
  </div>
</template>

<style scoped>
.project-card-horizontal {
  transition: all 0.3s ease;
}

.hide-scrollbar {
  -ms-overflow-style: none;
  scrollbar-width: none;
}

.hide-scrollbar::-webkit-scrollbar {
  display: none;
}

@media (max-width: 1023px) {
  .desktop-track {
    width: max-content;
  }
}
</style>
