<script setup>
import { MoveRight, ArrowLeft } from 'lucide-vue-next'

const allProjects = [
  {
    id: 1,
    title: 'Sarvesukhantu Swaha',
    category: 'CMS',
    image: '/images/projects/sarvesukhantu.png',
    tags: ['Tailwind', 'Apline', 'Laravel','Livewire', 'MySQL'],
    link: 'https://sarvesukhantuswaha.org/',
    height: 'tall'
  },
  {
    id: 2,
    title: 'Golfo Radio',
    category: 'Frontend',
    image: '/images/projects/golfo-radio.png',
    tags: ['Vue', 'Tailwind', 'axios'],
    link: 'https://golforadio.com/',
    height: 'tall'
  },
  {
    id: 3,
    title: 'Hair Creation',
    category: 'HRMS/CMS',
    image: '/images/projects/hair-creation.png',
    tags: ['Vue', 'Tailwind', 'Firebase','PWA'],
    link: 'https://hair-creation-8ffc3.web.app/'
  },
  {
    id: 4,
    title: 'Capmagic',
    category: 'Data Analysis Tool',
    image: '/images/projects/capmagic.png',
    tags: ['Vue', 'Vuetify', 'Laravel','PostgreSQL'],
    link: 'https://capmagic.net/',
    height: 'tall'
  },
  {
    id: 5,
    title: 'Ashray Infrastructure',
    category: 'Finance App',
    image: '/images/projects/ashray-infrastructure.png',
    tags: ['Golang', 'Vue', 'PostgreSQL','tailwind'],
    link: 'https://app.ashrayinfrastructure.com/'
  },
  {
    id: 6,
    title: 'QRGEN',
    category: 'QR Code Generator',
    image: '/images/projects/qr-gen.png',
    tags: ['Nuxt', 'Vue', 'Tailwind'],
    link: 'https://qr-code-gen-nuxt-sbk.web.app/',
    height: 'tall'
  }, 
  {
    id: 7,
    title: 'Chit Fund Management System',
    category: 'Finance App',
    image: '/images/projects/chit-fund.png',
    tags: ['Nuxt', 'Vue', 'Tailwind', 'firebase','PWA'],
    link: 'https://chitthi-b0db7.web.app/',
    height: 'tall'
  },
]
</script>

<template>
  <div class="min-h-screen py-32">
    <div class="max-w-7xl mx-auto px-6">
      <!-- Header -->
      <div class="mb-20">
        <NuxtLink to="/" class="inline-flex items-center gap-3 text-[#F2613F] font-bold mb-8  transition-colors">
          <ArrowLeft class="w-5 h-5" />
          BACK TO HOME
        </NuxtLink>
        
        <h1 class="text-6xl md:text-8xl font-black font-heading mb-6">
          ALL <span class="text-[#F2613F]">PROJECTS.</span>
        </h1>
        <p class="text-gray-400 text-xl max-w-2xl">
          A comprehensive collection of my work spanning various industries and technologies.
        </p>
      </div>

      <!-- Masonry Grid -->
      <div class="masonry-grid">
        <div 
          v-for="project in allProjects" 
          :key="project.id"
          :class="[
            'masonry-item group',
            project.height === 'tall' ? 'row-span-2' : project.height === 'short' ? 'row-span-1' : 'row-span-1'
          ]"
        >
          
            <div class="glass-card overflow-hidden h-full flex flex-col">
              <a 
              :href="project.link" 
              class=""
              target="_blank"
            >
              <div class="aspect-[4/3] relative overflow-hidden flex-shrink-0">
                <img 
                  :src="project.image" 
                  :alt="project.title" 
                  class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" 
                />
                <div class="absolute inset-0 bg-gradient-to-t from-gray-950/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                  <div class="flex gap-2 flex-wrap">
                    <span v-for="tag in project.tags" :key="tag" class="px-3 py-1 rounded-md bg-white/10 backdrop-blur-md text-xs font-bold">
                      {{ tag }}
                    </span>
                  </div>
                </div>
              </div>
              
              <div class="p-8 flex-grow flex flex-col">
                <p class="text-violet-400 font-bold text-xs uppercase tracking-widest mb-2">{{ project.category }}</p>
                <h3 class="text-2xl font-bold text-white mb-3">{{ project.title }}</h3>
                <p class="text-gray-400 text-sm mb-6 flex-grow">{{ project.description }}</p>
              </div>
              </a>
            </div>

        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.masonry-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  grid-auto-rows: 280px;
  gap: 2rem;
}

.masonry-item {
  transition: all 0.3s ease;
}

@media (max-width: 768px) {
  .masonry-grid {
    grid-template-columns: 1fr;
    grid-auto-rows: auto;
  }
  
  .masonry-item {
    grid-row: span 1 !important;
  }
}
</style>
