<script setup>
import { useWindowScroll } from '@vueuse/core'

const { y } = useWindowScroll()
const scrolled = computed(() => y.value > 50)

const isMenuOpen = ref(false)
const toggleMenu = () => {
  isMenuOpen.value = !isMenuOpen.value
}

const closeMenu = () => {
  isMenuOpen.value = false
}

// Lock body scroll when mobile menu is open
watch(isMenuOpen, (val) => {
  if (process.client) {
    document.body.style.overflow = val ? 'hidden' : ''
  }
})
</script>

<template>
  <div class="relative min-h-screen">
    <div class="bg-mesh" />
    
    <!-- Navigation -->
    <nav 
      class="fixed top-0 left-0 w-full z-[100] transition-all duration-500"
      :class="[scrolled || isMenuOpen ? 'py-4 bg-[#0C0C0C]/95 backdrop-blur-xl border-b border-[#F2613F]/30 shadow-sm' : 'py-8 bg-transparent']"
    >
      <div class="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <NuxtLink to="/" @click="closeMenu" class="h-12 w-auto flex items-center gap-2 group relative z-10 transition-transform hover:scale-105">
          <img src="/images/logo.png" alt="GLITCHHEAD Logo" class="h-48 max-w-[220px] object-contain"/>
        </NuxtLink>
        
        <!-- Desktop Nav -->
        <div class="hidden md:flex items-center gap-12">
          <NuxtLink to="#projects" class="text-sm font-bold text-white/90 hover:text-[#F2613F] transition-colors">PROJECTS</NuxtLink>
          <NuxtLink to="#about" class="text-sm font-bold text-white/90 hover:text-[#F2613F] transition-colors">ABOUT</NuxtLink>
          <NuxtLink to="#services" class="text-sm font-bold text-white/90 hover:text-[#F2613F] transition-colors">SERVICES</NuxtLink>
          <NuxtLink to="#contact" class="px-6 py-2.5 bg-[#F2613F] text-white text-sm font-black rounded-full hover:bg-[#9B3922] hover:shadow-lg hover:shadow-[#F2613F]/30 transition-all">
            LET'S WORK
          </NuxtLink>
        </div>

        <!-- Mobile Toggle -->
        <button 
          @click="toggleMenu"
          class="md:hidden relative z-10 w-10 h-10 flex flex-col items-center justify-center gap-1.5"
          aria-label="Toggle Menu"
        >
          <span 
            class="w-6 h-0.5 bg-white transition-all duration-300"
            :class="{ 'rotate-45 translate-y-2': isMenuOpen }"
          ></span>
          <span 
            class="w-6 h-0.5 bg-white transition-all duration-300"
            :class="{ 'opacity-0': isMenuOpen }"
          ></span>
          <span 
            class="w-6 h-0.5 bg-white transition-all duration-300"
            :class="{ '-rotate-45 -translate-y-2': isMenuOpen }"
          ></span>
        </button>
      </div>

      <!-- Mobile Menu Overlay -->
      <transition
        enter-active-class="transition duration-500 ease-out"
        enter-from-class="opacity-0 translate-y-[-20px]"
        enter-to-class="opacity-100 translate-y-0"
        leave-active-class="transition duration-300 ease-in"
        leave-from-class="opacity-100 translate-y-0"
        leave-to-class="opacity-0 translate-y-[-20px]"
      >
        <div 
          v-if="isMenuOpen"
          class="absolute top-full left-0 w-full h-screen bg-[#0C0C0C]/95 backdrop-blur-2xl border-b border-[#F2613F]/30 flex flex-col p-8 gap-8 md:hidden"
        >
          <NuxtLink to="#projects" @click="closeMenu" class="text-4xl font-black text-white">PROJECTS</NuxtLink>
          <NuxtLink to="#about" @click="closeMenu" class="text-4xl font-black text-white">ABOUT</NuxtLink>
          <NuxtLink to="#services" @click="closeMenu" class="text-4xl font-black text-white">SERVICES</NuxtLink>
          <hr class="border-[#F2613F]/30" />
          <NuxtLink to="#contact" @click="closeMenu" class="text-2xl font-black text-[#F2613F]">LET'S WORK</NuxtLink>
          
          <div class="mt-auto pb-20 flex gap-6">
            <a href="https://www.linkedin.com/in/sourabh-kahar-6558a7193/" class="text-sm font-bold text-white/60 underline" target="_blank">LINKEDIN</a>
            <a href="https://github.com/sourabhkahar" class="text-sm font-bold text-white/60 underline" target="_blank">GITHUB</a>
          </div>
        </div>
      </transition>
    </nav>

    <main>
      <NuxtPage />
    </main>

    <!-- Footer -->
    <footer class="py-12 border-t border-[#F2613F]/30 relative overflow-hidden bg-black">
      <div class="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center text-center md:text-left gap-8">
        <div class="flex flex-col items-center md:items-start gap-4">
          <NuxtLink to="/" class=" w-auto transition-transform hover:scale-105">
            <img src="/images/logo.png" alt="GLITCHHEAD Logo" class="h-48 w-auto object-contain"/>
          </NuxtLink>
        </div>
        <p class="text-white/80 text-sm">© 2026 Glitch Head. All rights reserved.</p>
        <div class="flex gap-8">
          <a href="https://www.linkedin.com/in/sourabh-kahar-6558a7193/" class="text-white/80 hover:text-[#F2613F] transition-colors font-semibold" target="_blank">LINKEDIN</a>
          <a href="https://github.com/sourabhkahar" class="text-white/80 hover:text-[#F2613F] transition-colors font-semibold" target="_blank">GITHUB</a>
        </div>
      </div>
    </footer>
  </div>
</template>

<style>
.page-enter-active,
.page-leave-active {
  transition: all 0.4s ease-in-out;
}
.page-enter-from,
.page-leave-to {
  opacity: 0;
  filter: blur(1rem);
}
</style>
